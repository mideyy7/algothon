# model_portfolio_lgbm_riskparity.py
# pip install lightgbm scikit-learn

import os
import re
import json
import math
import numpy as np
import pandas as pd

from dataclasses import dataclass
from typing import Dict, List, Tuple

from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from scipy.stats import spearmanr

import lightgbm as lgb


# ----------------------------
# Config
# ----------------------------
DATA_DIR = "."  # set to your PyCharm folder, or keep "." if you run from that folder
PRICES_CSV = os.path.join(DATA_DIR, "prices.csv")
VOLUMES_CSV = os.path.join(DATA_DIR, "volumes.csv")
SIGNALS_CSV = os.path.join(DATA_DIR, "signals.csv")
CASHRATE_CSV = os.path.join(DATA_DIR, "cash_rate.csv")

OUT_DIR = os.path.join(DATA_DIR, "stats_out")
os.makedirs(OUT_DIR, exist_ok=True)


@dataclass
class FeatureConfig:
    k_list: List[int] = None
    vol_lookback: int = 20
    cov_lookback: int = 60
    top_n: int = 5  # for spread metrics

    def __post_init__(self):
        if self.k_list is None:
            self.k_list = [4, 8, 16, 32]


# ----------------------------
# Loading + reshaping
# ----------------------------
def load_prices_volumes_signals_cashrate() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    prices = pd.read_csv(PRICES_CSV, parse_dates=["date"]).sort_values("date")
    vols = pd.read_csv(VOLUMES_CSV, parse_dates=["date"]).sort_values("date")
    sigs = pd.read_csv(SIGNALS_CSV, parse_dates=["date"]).sort_values("date")
    cash = pd.read_csv(CASHRATE_CSV, parse_dates=["date"]).sort_values("date")

    return prices, vols, sigs, cash


def to_long_prices(prices: pd.DataFrame) -> pd.DataFrame:
    return prices.melt(id_vars="date", var_name="asset", value_name="price").sort_values(["date", "asset"])


def to_long_volumes(vols: pd.DataFrame) -> pd.DataFrame:
    longv = vols.melt(id_vars="date", var_name="asset_raw", value_name="volume")
    longv["asset"] = longv["asset_raw"].str.replace(r"_vol$", "", regex=True)
    return longv.drop(columns=["asset_raw"]).sort_values(["date", "asset"])


def to_long_signals(sigs: pd.DataFrame) -> pd.DataFrame:
    """
    signals.csv columns look like: INSTRUMENT_1_trend4, INSTRUMENT_1_trend8, ...
    output columns: date, asset, trend4, trend8, ...
    """
    long = sigs.melt(id_vars="date", var_name="key", value_name="trend_val")
    m = long["key"].str.extract(r"^(INSTRUMENT_\d+)_trend(\d+)$")
    long["asset"] = m[0]
    long["k"] = m[1].astype(float)
    long = long.dropna(subset=["asset", "k"])

    pivot = long.pivot_table(index=["date", "asset"], columns="k", values="trend_val", aggfunc="first")
    pivot.columns = [f"trend{int(c)}" for c in pivot.columns]
    pivot = pivot.reset_index().sort_values(["date", "asset"])
    return pivot


def cashrate_features(cash: pd.DataFrame) -> pd.DataFrame:
    """
    Use a simple short-rate proxy + curve slope.
    Adjust columns if you prefer different tenors.
    """
    c = cash.copy()

    # safe picks (these exist in your file)
    short = "3mo"
    mid = "2yr"
    long = "10yr"

    for col in [short, mid, long]:
        if col not in c.columns:
            raise ValueError(f"cash_rate.csv missing column: {col}")

    c = c[["date", short, mid, long]].sort_values("date")

    # forward fill rates (there are NaNs early in history)
    c[[short, mid, long]] = c[[short, mid, long]].ffill()

    c["rate_short"] = c[short] / 100.0
    c["rate_slope_10y_3m"] = (c[long] - c[short]) / 100.0
    c["rate_slope_2y_3m"] = (c[mid] - c[short]) / 100.0
    c["rate_short_chg_5"] = c["rate_short"].diff(5)
    c["rate_short_chg_1"] = c["rate_short"].diff(1)

    return c[["date", "rate_short", "rate_slope_10y_3m", "rate_slope_2y_3m", "rate_short_chg_5", "rate_short_chg_1"]]


# ----------------------------
# Feature engineering (your formulas included)
# ----------------------------
def add_return_features(df: pd.DataFrame, cfg: FeatureConfig) -> pd.DataFrame:
    """
    df must have columns: date, asset, price, volume, trendK..., rate_...
    """
    out = df.copy()
    out = out.sort_values(["asset", "date"])

    # basic returns
    out["ret_1"] = out.groupby("asset")["price"].pct_change()

    # rolling vol sigmahat
    out["sigma_hat"] = out.groupby("asset")["ret_1"].rolling(cfg.vol_lookback).std().reset_index(level=0, drop=True)

    # volume features
    out["vol_chg_1"] = out.groupby("asset")["volume"].pct_change()
    out["vol_chg_5"] = out.groupby("asset")["volume"].pct_change(5)
    out["vol_z_20"] = (
        out.groupby("asset")["volume"]
        .transform(lambda x: (x - x.rolling(20).mean()) / (x.rolling(20).std() + 1e-12))
    )

    # your momentum + vol-normalised strength for each k
    for k in cfg.k_list:
        # r^(k) = (P_t - P_{t-k}) / P_{t-k}
        out[f"mom_r_{k}"] = out.groupby("asset")["price"].pct_change(k)

        # s = r^(k) / sigma_hat
        out[f"mom_s_{k}"] = out[f"mom_r_{k}"] / (out["sigma_hat"] + 1e-12)

        # a smooth f(|s|): tanh is stable and bounded
        out[f"mom_f_{k}"] = np.tanh(np.abs(out[f"mom_s_{k}"]))

        # (for reference) w = sign(s)*f(|s|) — we won't use this directly because portfolio must be long-only
        out[f"mom_w_signed_{k}"] = np.sign(out[f"mom_s_{k}"]) * out[f"mom_f_{k}"]

    return out


def make_panel_dataset(cfg: FeatureConfig) -> pd.DataFrame:
    prices, vols, sigs, cash = load_prices_volumes_signals_cashrate()

    p = to_long_prices(prices)
    v = to_long_volumes(vols)
    s = to_long_signals(sigs)
    c = cashrate_features(cash)

    # merge
    df = p.merge(v, on=["date", "asset"], how="left")
    df = df.merge(s, on=["date", "asset"], how="left")
    df = df.merge(c, on="date", how="left")

    df = add_return_features(df, cfg)

    # next-day return target
    df["y_next_ret"] = df.groupby("asset")["ret_1"].shift(-1)

    return df.sort_values(["date", "asset"])


def get_feature_cols(df: pd.DataFrame, cfg: FeatureConfig) -> List[str]:
    base = [
        "ret_1",
        "sigma_hat",
        "vol_chg_1",
        "vol_chg_5",
        "vol_z_20",
        "rate_short",
        "rate_slope_10y_3m",
        "rate_slope_2y_3m",
        "rate_short_chg_5",
        "rate_short_chg_1",
    ]

    # include provided trend signals
    trend_cols = [c for c in df.columns if re.match(r"^trend\d+$", c)]

    # include engineered momentum cols
    mom_cols = []
    for k in cfg.k_list:
        mom_cols += [f"mom_r_{k}", f"mom_s_{k}", f"mom_f_{k}"]

    cols = base + sorted(trend_cols) + mom_cols
    cols = [c for c in cols if c in df.columns]
    return cols


# ----------------------------
# LightGBM training + metrics
# ----------------------------
def time_split_dates(df: pd.DataFrame, n_splits: int = 5) -> List[Tuple[np.ndarray, np.ndarray]]:
    """
    Split by unique dates to prevent same-date leakage across assets.
    """
    dates = np.array(sorted(df["date"].unique()))
    tscv = TimeSeriesSplit(n_splits=n_splits)
    splits = []
    for tr, va in tscv.split(dates):
        splits.append((dates[tr], dates[va]))
    return splits


def evaluate_cross_sectional(df_pred: pd.DataFrame, top_n: int) -> Dict[str, float]:
    """
    Metrics that care about cross-sectional ranking:
    - Spearman IC across assets each day, averaged
    - top-minus-bottom realised return spread
    """
    ics = []
    spreads = []

    for d, g in df_pred.groupby("date"):
        g = g.dropna(subset=["y", "yhat"])
        if len(g) < 3:
            continue

        ic = spearmanr(g["yhat"], g["y"]).correlation
        if not np.isnan(ic):
            ics.append(ic)

        g2 = g.sort_values("yhat", ascending=False)
        top = g2.head(top_n)["y"].mean()
        bot = g2.tail(top_n)["y"].mean()
        spreads.append(top - bot)

    return {
        "ic_spearman_mean": float(np.nanmean(ics)) if len(ics) else np.nan,
        "top_minus_bottom_mean": float(np.nanmean(spreads)) if len(spreads) else np.nan,
    }


def train_lgbm_panel(df: pd.DataFrame, cfg: FeatureConfig, n_splits: int = 5) -> Tuple[lgb.LGBMRegressor, pd.DataFrame]:
    feat_cols = get_feature_cols(df, cfg)

    # drop rows with missing essentials
    data = df.dropna(subset=feat_cols + ["y_next_ret"]).copy()

    splits = time_split_dates(data, n_splits=n_splits)
    fold_metrics = []

    # a simple, strong default (tune later if needed)
    model = lgb.LGBMRegressor(
        n_estimators=1500,
        learning_rate=0.02,
        num_leaves=63,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_lambda=1.0,
        random_state=42,
        n_jobs=-1,
    )

    for fold, (tr_dates, va_dates) in enumerate(splits, start=1):
        tr = data[data["date"].isin(tr_dates)]
        va = data[data["date"].isin(va_dates)]

        X_tr, y_tr = tr[feat_cols], tr["y_next_ret"]
        X_va, y_va = va[feat_cols], va["y_next_ret"]

        model.fit(
            X_tr,
            y_tr,
            eval_set=[(X_va, y_va)],
            eval_metric="l2",
            callbacks=[lgb.early_stopping(stopping_rounds=100, verbose=False)],
        )

        yhat = model.predict(X_va)
        rmse = math.sqrt(mean_squared_error(y_va, yhat))
        mae = mean_absolute_error(y_va, yhat)
        r2 = r2_score(y_va, yhat)

        df_pred = va[["date", "asset"]].copy()
        df_pred["y"] = y_va.values
        df_pred["yhat"] = yhat

        xs = evaluate_cross_sectional(df_pred, top_n=cfg.top_n)

        fold_metrics.append(
            {
                "fold": fold,
                "train_dates": f"{tr_dates[0]}..{tr_dates[-1]}",
                "val_dates": f"{va_dates[0]}..{va_dates[-1]}",
                "rmse": rmse,
                "mae": mae,
                "r2": r2,
                **xs,
                "best_iter": int(getattr(model, "best_iteration_", model.n_estimators)),
            }
        )

    metrics_df = pd.DataFrame(fold_metrics)
    metrics_df.to_csv(os.path.join(OUT_DIR, "lgbm_cv_metrics.csv"), index=False)

    # refit on full data with best_iteration heuristic (median best_iter)
    best_iter = int(np.nanmedian(metrics_df["best_iter"].values))
    final = lgb.LGBMRegressor(
        n_estimators=max(200, best_iter),
        learning_rate=0.02,
        num_leaves=63,
        subsample=0.8,
        colsample_bytree=0.8,
        reg_lambda=1.0,
        random_state=42,
        n_jobs=-1,
    )
    final.fit(data[feat_cols], data["y_next_ret"])
    return final, metrics_df


# ----------------------------
# Cross-sectional ranking -> Risk budgets -> Long-only Risk Parity
# ----------------------------
def softmax(x: np.ndarray, temp: float = 1.0) -> np.ndarray:
    z = (x - np.nanmax(x)) / max(1e-12, temp)
    e = np.exp(z)
    return e / (e.sum() + 1e-12)


def risk_contributions(w: np.ndarray, cov: np.ndarray) -> np.ndarray:
    # RC_i = w_i * (Sigma w)_i
    m = cov @ w
    return w * m


def long_only_risk_parity(cov: np.ndarray, budgets: np.ndarray, iters: int = 4000, eps: float = 1e-10) -> np.ndarray:
    """
    Long-only risk parity matching budgets (budgets sum to 1, budgets>=0).
    Simple multiplicative update on risk contributions + projection to simplex.
    """
    n = len(budgets)
    b = np.clip(budgets, 0.0, None)
    b = b / (b.sum() + eps)

    # init at budgets
    w = np.maximum(b, 1e-6)
    w = w / w.sum()

    for _ in range(iters):
        rc = risk_contributions(w, cov)
        tot = rc.sum() + eps
        rc_frac = rc / tot

        # multiplicative correction
        mult = np.clip(b / (rc_frac + eps), 0.2, 5.0)
        w = w * mult

        # project to simplex (normalize + floor)
        w = np.maximum(w, 1e-10)
        w = w / (w.sum() + eps)

    return w


def build_cov_from_returns(df: pd.DataFrame, date: pd.Timestamp, lookback: int) -> Tuple[np.ndarray, List[str]]:
    """
    Build covariance matrix from trailing returns up to 'date' (excluding date).
    """
    sub = df[df["date"] < date].copy()
    sub = sub.sort_values(["date", "asset"])

    # take last lookback dates
    dates = sorted(sub["date"].unique())
    dates = dates[-lookback:] if len(dates) > lookback else dates
    sub = sub[sub["date"].isin(dates)]

    piv = sub.pivot(index="date", columns="asset", values="ret_1").dropna(axis=1, how="all")
    piv = piv.fillna(0.0)

    assets = list(piv.columns)
    cov = np.cov(piv.values.T)
    cov = cov + np.eye(cov.shape[0]) * 1e-8  # tiny ridge

    return cov, assets


def portfolio_from_model(
    df: pd.DataFrame,
    model: lgb.LGBMRegressor,
    cfg: FeatureConfig,
    asof_date: pd.Timestamp,
    rank_temp: float = 1.0,
) -> pd.DataFrame:
    """
    1) predict next return for each asset on asof_date
    2) cross-sectional ranking -> positive scores
    3) risk budgets proportional to scores
    4) long-only risk parity on trailing covariance
    """
    feat_cols = get_feature_cols(df, cfg)
    snap = df[df["date"] == asof_date].dropna(subset=feat_cols).copy()

    if snap.empty:
        raise ValueError(f"No usable rows on asof_date={asof_date} (maybe early NaNs).")

    snap["yhat"] = model.predict(snap[feat_cols])

    # cross-sectional ranking signal -> positive "strength"
    # (you can also clip negatives; here we softmax so all budgets >= 0)
    budgets = softmax(snap["yhat"].values, temp=rank_temp)

    cov, cov_assets = build_cov_from_returns(df, asof_date, lookback=cfg.cov_lookback)

    # align budgets to covariance assets
    snap = snap.set_index("asset").reindex(cov_assets).dropna(subset=["yhat"]).copy()
    budgets = softmax(snap["yhat"].values, temp=rank_temp)

    w = long_only_risk_parity(cov=cov, budgets=budgets)

    out = pd.DataFrame({"asset": cov_assets, "weight": w})
    out["weight"] = out["weight"] / out["weight"].sum()
    out = out.sort_values("asset").reset_index(drop=True)

    # sanity constraints (challenge requires sum=1 and non-negative)  :contentReference[oaicite:1]{index=1}
    out["weight"] = np.clip(out["weight"], 0.0, None)
    out["weight"] = out["weight"] / out["weight"].sum()

    return out


def save_submission(team_name: str, round_n: int, weights: pd.DataFrame, out_dir: str = ".") -> str:
    fn = f"{team_name}_round_{round_n}.csv"
    path = os.path.join(out_dir, fn)
    weights[["asset", "weight"]].to_csv(path, index=False)
    return path


# ----------------------------
# Main
# ----------------------------
def main():
    cfg = FeatureConfig(k_list=[4, 8, 16, 32], vol_lookback=20, cov_lookback=60, top_n=5)

    df = make_panel_dataset(cfg)

    model, metrics_df = train_lgbm_panel(df, cfg, n_splits=5)
    print("\n=== LightGBM CV metrics (saved to stats_out/lgbm_cv_metrics.csv) ===")
    print(metrics_df.to_string(index=False))

    # choose latest date that has features (avoid early NaNs)
    feat_cols = get_feature_cols(df, cfg)
    usable_dates = df.dropna(subset=feat_cols).date.unique()
    asof_date = pd.Timestamp(sorted(usable_dates)[-1])
    print(f"\nBuilding portfolio for asof_date = {asof_date.date()}")

    weights = portfolio_from_model(df, model, cfg, asof_date=asof_date, rank_temp=1.0)
    print("\n=== Portfolio weights ===")
    print(weights.to_string(index=False))

    # save weights in required format
    team = "AAKK"
    round_n = 1
    out_path = save_submission(team, round_n, weights, out_dir=".")
    print(f"\nSaved submission CSV: {out_path}")

    # dump some metadata for verification/logging
    meta = {
        "asof_date": str(asof_date.date()),
        "feature_cols": get_feature_cols(df, cfg),
        "config": cfg.__dict__,
    }
    with open(os.path.join(OUT_DIR, "run_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)
    print(f"Saved run metadata: {os.path.join(OUT_DIR, 'run_meta.json')}")


if __name__ == "__main__":
    main()